#UML
Link de acceso al UML relaciones de clases cargado en ludicspark

[Acceso](https://lucid.app/lucidspark/9c33e496-62af-47e2-bd62-4e3ce103f668/edit?invitationId=inv_aa23c6b0-642e-4274-bba4-043c3354a92f#)
