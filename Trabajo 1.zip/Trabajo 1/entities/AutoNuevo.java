package entities;

public class AutoNuevo extends Vehiculo {   
     
    public AutoNuevo(String color, String marca, String modelo, String marcaRadio) {
        super(color, marca, modelo, marcaRadio);
    }

    public AutoNuevo(String color, String marca, String modelo, double precio, String marcaRadio) {
        super(color, marca, modelo, precio, marcaRadio);
    }
}
