package entities;

public class Radio {
    private String marca;

    public Radio(String marca) {
        this.marca = marca;
    }

    public Radio() {
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String rad) {
        this.marca = rad;
    }

    public void cambiarMarca(String string) {
        setMarca(string);
    }

    @Override
    public String toString() {
        return " marca= " + marca;
    }

}
