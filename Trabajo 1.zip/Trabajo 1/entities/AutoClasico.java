package entities;

public class AutoClasico extends Vehiculo {

    public AutoClasico(String color, String marca, String modelo, float precio) {
        super(color, marca, modelo, precio);
    }

    public AutoClasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }

    public AutoClasico(String color, String marca, String modelo, String marcaRadio) {
        super(color, marca, modelo, marcaRadio);
    }

    public AutoClasico(String color, String marca, String modelo, double precio, String marcaRadio) {
        super(color, marca, modelo, precio, marcaRadio);
    }

    public void nuevaRadio(String radioNueva) {
        this.setRadio(new Radio(radioNueva));
    }
}
